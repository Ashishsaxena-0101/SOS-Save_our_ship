package com.example.a.b.c.d.sos_save_our_ship

import android.media.Image

data class Fields(
    val name: String,
    val call: Long,
    val medicine: String,
    val icon: Int
)