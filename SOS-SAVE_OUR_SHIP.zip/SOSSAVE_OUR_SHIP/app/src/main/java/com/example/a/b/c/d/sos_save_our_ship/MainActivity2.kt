package com.example.a.b.c.d.sos_save_our_ship

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.list_of_fields.view.*
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.list_of_fields.*



class MainActivity2 : AppCompatActivity() {
    private val Fields = listOf<Fields>(
        Fields("Ambulance", 108, "Service open 24/7",R.drawable.ambulance),
        Fields("Police Station", 100, "We are here to protect",R.drawable.police),
        Fields("Fire Extinguisher",101, "Arriving at one call",R.drawable.fire),
        Fields("LPG Leak Helpline", 1906, ".",R.drawable.lpgleak),
        Fields("Women's helpline", 181, "Preserve your dignity",R.drawable.womenhelpline),
        Fields("Children emergency Helpline", 1098, "We are here to help",R.drawable.childhelpline),
        Fields("Disaster Management", 1078, "NDRF-आपदा सेवा सदैव सर्वत्र",R.drawable.disaster),
        Fields("Cyber Crime", 15620, "Your security , our responsibilty",R.drawable.cybercrime),
        Fields("Domestic abuse helpline number", 181, "Raise your voices",R.drawable.domesticv),
        Fields("Medical aid- unconscious and breathing", 108, "keep them in open air make sure nothing obstruct their airway",R.drawable.unconsious),
        Fields("Railway accidents helpline", 1072, "Call 108 if needed",R.drawable.train),
        Fields("Road accident emergency service",1073, "Call 108 if needed",R.drawable.roadaccident),
        Fields("Medical aid-Bleeding", 108, "do first aid as possible try to stop the blood right then DO NOT wait for the ambulance , the blood needs to be stopped.",R.drawable.ambulance),
        Fields("Petrol Pump", 0, ".",R.drawable.petrolpumps),
        Fields("Medical aid- unconscious and not breathing", 108, "make sure a trainer person performs CPR with hands only, rescue breathes can be given.",R.drawable.unconsiousandnotbreathing),
        Fields("Senior citizen helpline", 14567, "We are here for you",R.drawable.seniorcitizen),
        Fields("Road accident emergency service for National Highways", 1033, "-",R.drawable.ambulance),
        Fields("Public toilets", 0, "-",R.drawable.publictoilets),
        Fields("Fixing a punctured tyre", 0, "Go through-https://www.cyclescheme.co.uk/community/how-to-fix-a-puncture-2",R.drawable.howtomakeapuncture),
        Fields("Tourist Helpline", 18001113363, "-",R.drawable.tourist),
        )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        lvFields.adapter = object : BaseAdapter() {
            override fun getCount() = Fields.size
            override fun getItem(position: Int): Fields = Fields[position]
            override fun getItemId(position: Int): Long = getItem(position).hashCode().toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val itemView = layoutInflater.inflate(R.layout.list_of_fields, parent, false)
                val Fields = getItem(position)
                itemView.tvFieldName.text = Fields.name
                itemView.tvCall.text = "${Fields.call}"
                itemView.tvMedicines.text = Fields.medicine
                itemView.iviconimage.setImageResource(Fields.icon)

                return itemView
            }
        }
        lvFields.setOnItemClickListener { _, _, position, _ ->
            Toast.makeText(this, "Clicked on ${Fields[position]}", Toast.LENGTH_SHORT).show()

        }
    }
}

